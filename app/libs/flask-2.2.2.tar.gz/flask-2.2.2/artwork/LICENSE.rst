Copyright 2010 Pallets

This logo or a modified version may be used by anyone to refer to the
Flask project, but does not indicate endorsement by the project.

Redistribution and use in source (SVG) and binary (renders in PNG, etc.)
forms, with or without modification, are permitted provided that the
following conditions are met:

1.  Redistributions of source code must retain the above copyright
    notice and this list of conditions.

2.  Neither the name of the copyright holder nor the names of its
    contributors may be used to endorse or promote products derived from
    this software without specific prior written permission.

We would appreciate that you make the image a link to
https://palletsprojects.com/p/flask/ if you use it in a medium that
supports links.
